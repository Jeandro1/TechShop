<?php get_header(); ?>

<div class="opening">
    <p>Welkom op deze webshop.</p>
</div>

<?php get_footer(); ?>